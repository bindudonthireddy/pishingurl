from urllib.parse import urlparse
from flask import Flask, request, jsonify, render_template # type: ignore
from URL_Feature_Extraction import featureExtraction
from Model import model3
import pandas as pd
import requests

app = Flask(__name__, static_folder='static', template_folder='templates')

# Route for Home Page
@app.route('/')
def home():
    return render_template('index.html')

# Route for About Us Page
@app.route('/about')
def about():
    return render_template('about.html')

# Route for Contact Us Page
@app.route('/contact')
def contact():
    return render_template('contact.html')

# Route for Predict Page
@app.route('/predict')
def predict():
    return render_template('predict.html')

# API endpoint to handle prediction (example)
@app.route('/api/predict', methods=['POST'])
def predict_api():
    try:
        data = request.json()
        # url = data['input1']

        url = data.get('input1')

        # Convert URL to features
        features = featureExtraction(url)
        feature_names = ['Domain', 'Have_IP', 'Have_At', 'URL_Length', 'URL_Depth', 'Redirection', 
                         'https_Domain', 'TinyURL', 'Prefix/Suffix', 'iFrame', 'Mouse_Over', 'Right_Click', 'Web_Forwards']
        df = pd.DataFrame([features], columns=feature_names)
        df = df.drop('Domain', axis=1)

        # Predict
        prediction = model3.predict(df)
        result = 'phishing' if prediction[0] == 1 else 'legitimate'

        dns=0
        try:
            response=requests.head(url)
        except requests.ConnectionError:
            dns=1
        except requests.exceptions.RequestException:
            dns=1
        if dns==1:
            result = 'phishing'
        # return jsonify({'prediction': result})
        return jsonify({
            'status': 'success',
            'prediction': prediction,
            'message': 'Prediction calculated successfully'
        })
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 400

# Handle contact form submissions
@app.route('/api/contact', methods=['POST'])
def contact_api():
    try:
        data = request.json
        
        # Here you would typically save to a database
        print("Contact form submission received:")
        print(f"Name: {data.get('name')}")
        print(f"Email: {data.get('email')}")
        print(f"Message: {data.get('message')}")
        
        return jsonify({
            'status': 'success',
            'message': 'Thank you for your message! We will get back to you soon.'
        })
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 400

if __name__ == '__main__':
    app.run(debug=True)









        # input1 = float(data.get('input1', 0))