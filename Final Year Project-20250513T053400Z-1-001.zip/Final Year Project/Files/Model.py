#importing basic packages
import pandas as pd
import xgboost
from sklearn.model_selection import train_test_split

#Loading the data
data = pd.read_csv('Datafiles/5.urldata.csv')

#Dropping the Domain column
data = data.drop(['Domain'], axis = 1).copy()

# shuffling the rows in the dataset so that when splitting the train and test set are equally distributed
data = data.sample(frac=1).reset_index(drop=True)

# Separatating & assigning features and target columns to X & y
Y = data['Label']
X = data.drop('Label',axis=1)
X.shape, Y.shape

# Splitting the dataset into train and test sets: 80-20 split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.2, random_state = 12)

### Training the model
classifier=xgboost.XGBClassifier()

model3=xgboost.XGBClassifier(max_depth=9,min_child_weight=1,learning_rate=0.55,gamma=0.0,colsample_bytree=0.9,colsample_bylevel=0.95,n_estimators=15)

#fit the model
model3.fit(X_train, Y_train)
