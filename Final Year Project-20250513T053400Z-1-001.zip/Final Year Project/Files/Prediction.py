import pandas as pd
from URL_Feature_Extraction import featureExtraction
from Model import model3

# Function to convert a given URL into feature dataframe
def convert_inp(url):
    features=[]
    # features.append(featureExtraction(rl,1))
    features=featureExtraction(url)
    #converting the list to dataframe
    feature_names = ['Domain', 'Have_IP', 'Have_At', 'URL_Length', 'URL_Depth','Redirection', 
                      'https_Domain', 'TinyURL', 'Prefix/Suffix',
                        'iFrame', 'Mouse_Over','Right_Click', 'Web_Forwards']

    # Create an empty DataFrame with columns
    df = pd.DataFrame(columns=feature_names)

    # Inserting the Input url features into Dataframe
    df.loc[len(df)] = features

    # Deleting the Domain Column
    df=df.drop('Domain',axis=1)
    return df


# Function to predict the URL's status
def predict(df):
    prediction = model3.predict(df)
    if prediction==0:
        return 'legitimate'
    return 'phishing'


url1='https://platform.openai.com/settings/organization/api-keys'               # legitimate website
url2='jhomitevd2abj3fk.tor2web.org/'                                            # Phishing website

print("------------------------------------------------")
url=input("Enter a URL: ")
output=predict(convert_inp(url))

print("------------------------------------------------")
print(f"The given URL is {output}")
print("-------------------------------------------------------------------------------------------------")
print("-------------------------------------------------------------------------------------------------")