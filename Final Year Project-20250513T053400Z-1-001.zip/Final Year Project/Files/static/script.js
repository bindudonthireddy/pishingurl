// Contact Form Submission
document.getElementById('contactForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = {
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        message: document.getElementById('message').value
    };
    
    try {
        const response = await fetch('/api/contact', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (data.status === 'success') {
            alert(data.message);
            this.reset();
        } else {
            throw new Error(data.message);
        }
    } catch (error) {
        alert('Error submitting form: ' + error.message);
    }
});


//Prediction Form Submission
console.log("JavaScript is working!1");
document.getElementById('urlForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const url = document.getElementById('urlInput').value;

    fetch('/api/predict', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url: url }),
    })
    .then(response => response.json())
    .then(data => {
        const resultDiv = document.getElementById('result');
        resultDiv.textContent = `The given URL is ${data.prediction}`;
        resultDiv.style.color = data.prediction === 'phishing' ? 'red' : 'green';

        resultDiv.style.fontSize = '20px';
        resultDiv.style.fontWeight = 'bold';
        resultDiv.style.marginTop = '40px';
        resultDiv.style.marginLeft = '460px';
        resultDiv.style.marginRight = '460px';
        resultDiv.style.textAlign = 'center';
        resultDiv.style.backgroundColor = 'white';
        resultDiv.style.padding = '30px';
        resultDiv.style.borderRadius = '6px';
        resultDiv.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
    })
    .catch(error => {
        console.error('Error:', error);
    });
});
console.log("JavaScript is working2!");



// fetch('/predict2', {
//     method: 'POST',
//     headers: {
//         'Content-Type': 'application/json',
//     },
//     body: JSON.stringify({ url: url }),
// })




// const response = await fetch('/api/predict', {
//     method: 'POST',
//     headers: {
//         'Content-Type': 'application/json',
//     },
//     body: JSON.stringify({ url: url }),
// });
